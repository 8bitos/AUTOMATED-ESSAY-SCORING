ALTER TABLE essay_questions
DROP COLUMN rubric;
