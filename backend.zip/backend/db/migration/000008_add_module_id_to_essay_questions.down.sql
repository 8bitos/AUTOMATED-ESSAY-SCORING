
ALTER TABLE essay_questions
DROP COLUMN IF EXISTS module_id;
