ALTER TABLE essay_questions
ADD COLUMN rubric JSONB;
