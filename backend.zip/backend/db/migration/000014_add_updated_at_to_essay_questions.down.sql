ALTER TABLE essay_questions
DROP COLUMN updated_at;
