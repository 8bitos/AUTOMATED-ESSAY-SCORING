
DROP TABLE IF EXISTS class_members;
