ALTER TABLE materials
DROP COLUMN updated_at;
