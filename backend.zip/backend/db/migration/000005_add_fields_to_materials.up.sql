
ALTER TABLE materials
ADD COLUMN capaian_pembelajaran TEXT,
ADD COLUMN kata_kunci TEXT[];
