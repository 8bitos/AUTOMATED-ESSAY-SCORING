
DROP TABLE IF EXISTS essay_questions;
