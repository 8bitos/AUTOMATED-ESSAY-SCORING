
ALTER TABLE materials
DROP COLUMN IF EXISTS capaian_pembelajaran,
DROP COLUMN IF EXISTS kata_kunci;
