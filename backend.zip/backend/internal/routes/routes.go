package routes

import (
	"api-backend/internal/handlers" // Mengimpor package handlers untuk menangani permintaan HTTP.
	"api-backend/internal/services" // Mengimpor package services untuk logika bisnis.
	"database/sql"                           // Mengimpor package database/sql untuk interaksi dengan database.
	"encoding/json"                          // Mengimpor package encoding/json untuk encoding/decoding JSON.
	"github.com/gorilla/mux"                 // Mengimpor router Mux dari Gorilla Toolkit.
	"log"                                    // Mengimpor package log untuk logging.
	"net/http"                               // Mengimpor package net/http untuk fungsionalitas HTTP.
)

// respondWithJSONForPing adalah fungsi helper untuk mengirim respons JSON.
// Digunakan khususnya untuk endpoint ping sederhana.
func respondWithJSONForPing(w http.ResponseWriter, code int, payload interface{}) {
	response, _ := json.Marshal(payload) // Mengubah payload (biasanya map) menjadi JSON byte array.
	w.Header().Set("Content-Type", "application/json") // Mengatur header Content-Type ke application/json.
	w.WriteHeader(code)                                // Mengatur status kode HTTP.
	w.Write(response)                                  // Menulis respons JSON ke client.
}

// PingHandler adalah handler sederhana untuk menguji ketersediaan API.
// Mengembalikan pesan "pong" jika API responsif.
func PingHandler(w http.ResponseWriter, r *http.Request) {
	respondWithJSONForPing(w, http.StatusOK, map[string]string{"message": "pong"})
}

// SetupRoutes mengkonfigurasi semua rute aplikasi.
// Fungsi ini menerima objek router Mux, koneksi database, dan berbagai layanan (services)
// yang dibutuhkan oleh handler.
func SetupRoutes(router *mux.Router, db *sql.DB, materialService *services.MaterialService, essayQuestionService *services.EssayQuestionService) {
	// --- Inisialisasi Layanan (Services) ---
	// Layanan berisi logika bisnis dan berinteraksi dengan repository/database.
	authService := services.NewAuthService(db)
	
	// Inisialisasi AI Service. Log fatal jika gagal.
	aiService, err := services.NewAIService()
	if err != nil {
		log.Fatalf("FATAL: Could not initialize AI service: %v", err)
	}

	// ClassService memerlukan materialService dan essayQuestionService.
	classService := services.NewClassService(db, materialService, essayQuestionService)
	essaySubmissionService := services.NewEssaySubmissionService(db, aiService, essayQuestionService)
	aiResultService := services.NewAIResultService(db)
	teacherReviewService := services.NewTeacherReviewService(db)
	moduleService := services.NewModuleService(db)

	// --- Inisialisasi Handler ---
	// Handler menerima permintaan HTTP dan memanggil metode dari layanan.
	authHandlers := handlers.NewAuthHandlers(authService)
	gradeEssayHandlers := handlers.NewGradeEssayHandlers(aiService)
	classHandlers := handlers.NewClassHandlers(classService)
	materialHandlers := handlers.NewMaterialHandlers(materialService)
	essayQuestionHandlers := handlers.NewEssayQuestionHandlers(essayQuestionService)
	essaySubmissionHandlers := handlers.NewEssaySubmissionHandlers(essaySubmissionService, aiResultService)
	aiResultHandlers := handlers.NewAIResultHandlers(aiResultService)
	teacherReviewHandlers := handlers.NewTeacherReviewHandlers(teacherReviewService)
	devHandler := handlers.NewDevHandler(db) // Handler untuk pengembangan/debugging.
	moduleHandlers := handlers.NewModuleHandlers(moduleService)
	uploadHandler := handlers.NewUploadHandler()

	// --- Rute Publik (Tanpa Awalan /api) ---
	// Rute-rute ini dapat diakses langsung tanpa awalan API.
	router.HandleFunc("/", handlers.HelloHandler).Methods("GET")       // Contoh rute "Hello World".
	router.HandleFunc("/test", handlers.TestHandler).Methods("GET")     // Rute pengujian.

	// FileServer untuk melayani file yang diunggah.
	fs := http.FileServer(http.Dir("./uploads/"))
	router.PathPrefix("/uploads/").Handler(http.StripPrefix("/uploads/", fs))

	// Membuat subrouter untuk semua endpoint API dengan awalan "/api".
	api := router.PathPrefix("/api").Subrouter()

	// --- Rute API Publik (Tidak Memerlukan Otentikasi) ---
	// Rute-rute ini dapat diakses oleh siapa saja.
	api.HandleFunc("/login", authHandlers.LoginHandler).Methods("POST")
	api.HandleFunc("/register", authHandlers.RegisterHandler).Methods("POST")
	api.HandleFunc("/logout", authHandlers.LogoutHandler).Methods("POST")
	api.HandleFunc("/grade-essay", gradeEssayHandlers.GradeEssayHandler).Methods("POST") // Untuk menilai esai secara publik (tanpa login).
	api.HandleFunc("/classes-public", classHandlers.GetAllClassesHandler).Methods("GET") // Untuk mendapatkan daftar kelas secara publik.

	// Rute pengembangan/debugging.
	api.HandleFunc("/dev/tables", devHandler.GetTables).Methods("GET")

	// --- Rute Terlindungi (Memerlukan Otentikasi Pengguna) ---
	// Semua rute di bawah protectedRouter akan melewati AuthMiddleware.
	protectedRouter := api.PathPrefix("/").Subrouter()
	protectedRouter.Use(AuthMiddleware) // Menerapkan middleware otentikasi.

	// Rute khusus siswa atau pengguna terotentikasi.
	protectedRouter.HandleFunc("/student/join-class", classHandlers.JoinClassHandler).Methods("POST")
	protectedRouter.HandleFunc("/student/my-classes", classHandlers.GetStudentClassesHandler).Methods("GET")
	protectedRouter.HandleFunc("/student/classes/{classId}", classHandlers.GetStudentClassByIDHandler).Methods("GET")
	protectedRouter.HandleFunc("/ping", PingHandler).Methods("GET")       // Ping untuk pengguna terotentikasi.
	protectedRouter.HandleFunc("/me", authHandlers.MeHandler).Methods("GET") // Mendapatkan informasi pengguna saat ini.
	protectedRouter.HandleFunc("/upload", uploadHandler.UploadFileHandler).Methods("POST") // Untuk mengunggah file.
	protectedRouter.HandleFunc("/essay-questions/{questionId}", essayQuestionHandlers.GetEssayQuestionByIDHandler).Methods("GET") // Mendapatkan pertanyaan esai berdasarkan ID.
	
	// Rute untuk submission esai.
	protectedRouter.HandleFunc("/submissions", essaySubmissionHandlers.CreateEssaySubmissionHandler).Methods("POST")
	protectedRouter.HandleFunc("/submissions/{submissionId}", essaySubmissionHandlers.GetEssaySubmissionByIDHandler).Methods("GET")
	protectedRouter.HandleFunc("/submissions/{submissionId}", essaySubmissionHandlers.UpdateEssaySubmissionHandler).Methods("PUT")
	protectedRouter.HandleFunc("/submissions/{submissionId}", essaySubmissionHandlers.DeleteEssaySubmissionHandler).Methods("DELETE")
	protectedRouter.HandleFunc("/students/{studentId}/submissions", essaySubmissionHandlers.GetEssaySubmissionsByStudentIDHandler).Methods("GET")

	// Rute terkait hasil penilaian AI.
	protectedRouter.HandleFunc("/ai-results", aiResultHandlers.CreateAIResultHandler).Methods("POST")
	protectedRouter.HandleFunc("/ai-results/{resultId}", aiResultHandlers.GetAIResultByIDHandler).Methods("GET")
	protectedRouter.HandleFunc("/submissions/{submissionId}/ai-result", aiResultHandlers.GetAIResultBySubmissionIDHandler).Methods("GET")
	protectedRouter.HandleFunc("/ai-results/{resultId}", aiResultHandlers.UpdateAIResultHandler).Methods("PUT")
	protectedRouter.HandleFunc("/ai-results/{resultId}", aiResultHandlers.DeleteAIResultHandler).Methods("DELETE")

	// Rute terkait review dari guru.
	protectedRouter.HandleFunc("/teacher-reviews", teacherReviewHandlers.CreateTeacherReviewHandler).Methods("POST")
	protectedRouter.HandleFunc("/teacher-reviews/{reviewId}", teacherReviewHandlers.UpdateTeacherReviewHandler).Methods("PUT")
	protectedRouter.HandleFunc("/teacher-reviews/{reviewId}", teacherReviewHandlers.DeleteTeacherReviewHandler).Methods("DELETE")

	// --- Rute Khusus Guru (Memerlukan Otentikasi dan Peran Guru) ---
	// Semua rute di bawah teacherRouter akan melewati TeacherOnlyMiddleware (setelah AuthMiddleware).
	teacherRouter := protectedRouter.PathPrefix("/").Subrouter()
	teacherRouter.Use(TeacherOnlyMiddleware) // Menerapkan middleware khusus guru.
	
	// Rute terkait kelas khusus guru.
	teacherRouter.HandleFunc("/classes", classHandlers.GetClassesHandler).Methods("GET")          // Mendapatkan daftar kelas yang diajar guru.
	teacherRouter.HandleFunc("/classes", classHandlers.CreateClassHandler).Methods("POST")        // Membuat kelas baru.
	teacherRouter.HandleFunc("/classes/{classId}", classHandlers.GetClassByIDHandler).Methods("GET") // Mendapatkan detail kelas berdasarkan ID.
	teacherRouter.HandleFunc("/classes/{classId}/students", classHandlers.GetStudentsByClassIDHandler).Methods("GET") // Mendapatkan siswa dalam kelas.
	teacherRouter.HandleFunc("/classes/{classId}/students/{studentId}", classHandlers.RemoveStudentFromClassHandler).Methods("DELETE") // Menghapus siswa dari kelas.

	// Rute terkait materi khusus guru.
	teacherRouter.HandleFunc("/materials", materialHandlers.CreateMaterialWithQuestionsHandler).Methods("POST") // Membuat materi baru (termasuk pertanyaan).
	teacherRouter.HandleFunc("/materials/{materialId}", materialHandlers.GetMaterialByIDHandler).Methods("GET") // Mendapatkan detail materi.
	teacherRouter.HandleFunc("/classes/{classId}/materials", materialHandlers.GetMaterialsByClassIDHandler).Methods("GET") // Mendapatkan materi berdasarkan kelas.
	teacherRouter.HandleFunc("/materials/{materialId}", materialHandlers.UpdateMaterialHandler).Methods("PUT") // Memperbarui materi.
	teacherRouter.HandleFunc("/materials/{materialId}", materialHandlers.DeleteMaterialHandler).Methods("DELETE") // Menghapus materi.

	// Rute terkait pertanyaan esai khusus guru.
	teacherRouter.HandleFunc("/materials/{materialId}/essay-questions", essayQuestionHandlers.GetEssayQuestionsByMaterialIDHandler).Methods("GET") // Mendapatkan pertanyaan esai berdasarkan materi.
	teacherRouter.HandleFunc("/essay-questions/{questionId}", essayQuestionHandlers.DeleteEssayQuestionHandler).Methods("DELETE") // Menghapus pertanyaan esai.
	teacherRouter.HandleFunc("/essay-questions/{questionId}", essayQuestionHandlers.UpdateEssayQuestionHandler).Methods("PUT") // Memperbarui pertanyaan esai.

	// Rute terkait modul khusus guru.
	teacherRouter.HandleFunc("/modules", moduleHandlers.CreateModuleHandler).Methods("POST") // Membuat modul baru.
	teacherRouter.HandleFunc("/materials/{materialId}/modules", moduleHandlers.GetModulesByMaterialIDHandler).Methods("GET") // Mendapatkan modul berdasarkan materi.

	// Rute terkait submission esai khusus guru.
	teacherRouter.HandleFunc("/essay-questions/{questionId}/submissions", essaySubmissionHandlers.GetEssaySubmissionsByQuestionIDHandler).Methods("GET") // Mendapatkan submission esai berdasarkan pertanyaan.

}
