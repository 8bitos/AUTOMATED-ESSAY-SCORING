package handlers

import (
	"api-backend/internal/models"
	"api-backend/internal/services"
	"api-backend/internal/utils" // Import utils for JWT
	"encoding/json"
	"net/http"
	"time" // Import time for cookie expiration
)

// AuthHandlers holds dependencies for authentication handlers.
type AuthHandlers struct {
	AuthService *services.AuthService
}

// NewAuthHandlers creates a new instance of AuthHandlers.
func NewAuthHandlers(authService *services.AuthService) *AuthHandlers {
	return &AuthHandlers{AuthService: authService}
}

// respondWithJSON is a helper to write JSON responses.
func respondWithJSON(w http.ResponseWriter, code int, payload interface{}) {
	response, _ := json.Marshal(payload)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	w.Write(response)
}

// respondWithError is a helper to write JSON error responses.
func respondWithError(w http.ResponseWriter, code int, message string) {
	respondWithJSON(w, code, map[string]string{"message": message})
}

// LoginHandler handles user login, sets an HttpOnly cookie, and returns user data.
func (h *AuthHandlers) LoginHandler(w http.ResponseWriter, r *http.Request) {
	var req models.UserLoginRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	// Authenticate user using the identifier (email or username)
	user, err := h.AuthService.AuthenticateUser(req.Identifier, req.Password)
	if err != nil {
		respondWithError(w, http.StatusUnauthorized, "Invalid credentials")
		return
	}

	// Generate JWT token
	tokenString, err := utils.GenerateJWT(user)
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Failed to generate token")
		return
	}

	// Set JWT as an HttpOnly cookie
	http.SetCookie(w, &http.Cookie{
		Name:     "auth_token",
		Value:    tokenString,
		Expires:  time.Now().Add(24 * time.Hour),
		HttpOnly: true,
		Path:     "/",
		SameSite: http.SameSiteLaxMode, // Explicitly set SameSite for better browser compatibility
		// Secure:   true, // Should be enabled in production (HTTPS)
	})

	// Return user data in the response body as expected by the frontend context
	respondWithJSON(w, http.StatusOK, user)
}

// RegisterHandler handles new user registration requests.
func (h *AuthHandlers) RegisterHandler(w http.ResponseWriter, r *http.Request) {
	var req models.UserRegisterRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	// Basic validation
	if req.NamaLengkap == "" || req.Username == "" || req.Email == "" || req.Password == "" || req.Peran == "" {
		respondWithError(w, http.StatusBadRequest, "All required fields must be provided")
		return
	}
	if req.Peran != "student" && req.Peran != "teacher" {
		respondWithError(w, http.StatusBadRequest, "Invalid role specified. Must be 'student' or 'teacher'.")
		return
	}

	// Register user
	registeredUser, err := h.AuthService.RegisterUser(req)
	if err != nil {
		// More specific error for existing user
		if err.Error() == "email or username already exists" {
			respondWithError(w, http.StatusConflict, err.Error())
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to register user")
		return
	}

	// Return the newly created user (without password)
	respondWithJSON(w, http.StatusCreated, registeredUser)
}

// MeHandler returns the currently authenticated user based on the session cookie.
func (h *AuthHandlers) MeHandler(w http.ResponseWriter, r *http.Request) {
	cookie, err := r.Cookie("auth_token")
	if err != nil {
		if err == http.ErrNoCookie {
			respondWithError(w, http.StatusUnauthorized, "No authorization token provided")
			return
		}
		respondWithError(w, http.StatusBadRequest, "Invalid cookie")
		return
	}

	tokenString := cookie.Value
	claims, err := utils.ValidateJWT(tokenString)
	if err != nil {
		respondWithError(w, http.StatusUnauthorized, "Invalid or expired token")
		return
	}

	user, err := h.AuthService.GetUserByID(claims.UserID)
	if err != nil {
		respondWithError(w, http.StatusNotFound, "User not found")
		return
	}

	respondWithJSON(w, http.StatusOK, user)
}

// LogoutHandler clears the authentication cookie.
func (h *AuthHandlers) LogoutHandler(w http.ResponseWriter, r *http.Request) {
	// Set the cookie with an expiration date in the past to delete it.
	http.SetCookie(w, &http.Cookie{
		Name:     "auth_token",
		Value:    "",
		Expires:  time.Unix(0, 0),
		HttpOnly: true,
		Path:     "/",
		SameSite: http.SameSiteLaxMode, // Match the login cookie policy
	})

	respondWithJSON(w, http.StatusOK, map[string]string{"message": "Successfully logged out"})
}
