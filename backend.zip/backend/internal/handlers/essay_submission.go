package handlers

import (
	"api-backend/internal/models"
	"api-backend/internal/services"
	"encoding/json"
	"log"
	"net/http"
	"strconv" // Added import
	"time"    // Added import

	"github.com/gorilla/mux"
)

// EssaySubmissionHandlers holds dependencies for essay submission-related handlers.
type EssaySubmissionHandlers struct {
	Service         *services.EssaySubmissionService
	AIResultService *services.AIResultService
}

// NewEssaySubmissionHandlers creates a new instance of EssaySubmissionHandlers.
func NewEssaySubmissionHandlers(s *services.EssaySubmissionService, ars *services.AIResultService) *EssaySubmissionHandlers {
	return &EssaySubmissionHandlers{Service: s, AIResultService: ars}
}

// CreateEssaySubmissionHandler handles the creation of a new essay submission.
func (h *EssaySubmissionHandlers) CreateEssaySubmissionHandler(w http.ResponseWriter, r *http.Request) {
	var req models.CreateEssaySubmissionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if req.QuestionID == "" || req.TeksJawaban == "" {
		respondWithError(w, http.StatusBadRequest, "Question ID and Teks Jawaban cannot be empty")
		return
	}

	// StudentID should come from the authenticated user
	studentID, ok := r.Context().Value("userID").(string)
	if !ok || studentID == "" {
		respondWithError(w, http.StatusUnauthorized, "User ID not found in context")
		return
	}

	newSubmission, gradeEssayResponse, err := h.Service.CreateEssaySubmission(req.QuestionID, studentID, req.TeksJawaban)
	if err != nil {
		log.Printf("ERROR: Failed to create essay submission in service: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Failed to create essay submission")
		return
	}

	// Create and save AIResult
	skorAI, parseErr := strconv.ParseFloat(gradeEssayResponse.Score, 64)
	if parseErr != nil {
		log.Printf("WARNING: Failed to parse AI score %s: %v", gradeEssayResponse.Score, parseErr)
		skorAI = 0.0 // Default to 0.0 if parsing fails
	}

	feedbackAI := gradeEssayResponse.Feedback
	
	// Marshal the full AI response for RawResponse field
	gradeEssayResponseJSON, marshalErr := json.Marshal(gradeEssayResponse)
	if marshalErr != nil {
		log.Printf("WARNING: Failed to marshal GradeEssayResponse to JSON: %v", marshalErr)
	}

	aiResult := &models.AIResult{
		SubmissionID: newSubmission.ID,
		SkorAI:       skorAI,
		UmpanBalikAI: &feedbackAI, // Addressable string
		RawResponse:  string(gradeEssayResponseJSON),
		GeneratedAt:  time.Now(),
	}

	createdAIResult, err := h.AIResultService.CreateAIResult(aiResult.SubmissionID, aiResult.SkorAI, aiResult.UmpanBalikAI, aiResult.LogsRAG)
	if err != nil {
		log.Printf("ERROR: Failed to create AI result for submission %s: %v", newSubmission.ID, err)
		// Decide whether to fail the entire submission or just log the AI result saving failure
		// For now, we'll log and continue, but this might need refinement.
	}

	// Respond with the submission and AI result
	responsePayload := map[string]interface{}{
		"submission": newSubmission,
		"ai_result":  createdAIResult,
	}

	respondWithJSON(w, http.StatusCreated, responsePayload)
}

// GetEssaySubmissionByIDHandler handles fetching a single essay submission by its ID.
func (h *EssaySubmissionHandlers) GetEssaySubmissionByIDHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered GetEssaySubmissionByIDHandler")

	vars := mux.Vars(r)
	submissionID, ok := vars["submissionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Submission ID is missing from URL")
		return
	}

	submission, err := h.Service.GetEssaySubmissionByID(submissionID)
	if err != nil {
		log.Printf("ERROR: Failed to get essay submission %s: %v", submissionID, err)
		if err.Error() == "essay submission not found" {
			respondWithError(w, http.StatusNotFound, "Essay submission not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve essay submission")
		return
	}

	log.Printf("DEBUG: Successfully fetched essay submission %s.", submissionID)
	respondWithJSON(w, http.StatusOK, submission)
}

// GetEssaySubmissionsByQuestionIDHandler handles fetching all essay submissions for a specific question.
func (h *EssaySubmissionHandlers) GetEssaySubmissionsByQuestionIDHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered GetEssaySubmissionsByQuestionIDHandler")

	vars := mux.Vars(r)
	questionID, ok := vars["questionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Question ID is missing from URL")
		return
	}

	submissions, err := h.Service.GetEssaySubmissionsByQuestionID(questionID)
	if err != nil {
		log.Printf("ERROR: Failed to get essay submissions for question %s: %v", questionID, err)
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve essay submissions")
		return
	}

	log.Printf("DEBUG: Successfully fetched %d essay submissions for question %s.", len(submissions), questionID)
	respondWithJSON(w, http.StatusOK, submissions)
}

// GetEssaySubmissionsByStudentIDHandler handles fetching all essay submissions by a specific student.
func (h *EssaySubmissionHandlers) GetEssaySubmissionsByStudentIDHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered GetEssaySubmissionsByStudentIDHandler")

	vars := mux.Vars(r)
	studentID, ok := vars["studentId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Student ID is missing from URL")
		return
	}

	// This handler should probably be secured to only allow a student to fetch their own submissions
	// or a teacher to fetch submissions of their students.
	// For now, assuming basic authentication
	
	submissions, err := h.Service.GetEssaySubmissionsByStudentID(studentID)
	if err != nil {
		log.Printf("ERROR: Failed to get essay submissions by student %s: %v", studentID, err)
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve essay submissions")
		return
	}

	log.Printf("DEBUG: Successfully fetched %d essay submissions by student %s.", len(submissions), studentID)
	respondWithJSON(w, http.StatusOK, submissions)
}

// UpdateEssaySubmissionHandler handles updating an existing essay submission.
func (h *EssaySubmissionHandlers) UpdateEssaySubmissionHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered UpdateEssaySubmissionHandler")

	vars := mux.Vars(r)
	submissionID, ok := vars["submissionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Submission ID is missing from URL")
		return
	}

	var req models.UpdateEssaySubmissionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	updatedSubmission, err := h.Service.UpdateEssaySubmission(submissionID, &req)
	if err != nil {
		log.Printf("ERROR: Failed to update essay submission %s: %v", submissionID, err)
		if err.Error() == "essay submission not found for update" {
			respondWithError(w, http.StatusNotFound, "Essay submission not found")
			return
		} else if err.Error() == "no fields to update" {
			respondWithError(w, http.StatusBadRequest, err.Error())
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to update essay submission")
		return
	}

	log.Printf("DEBUG: Successfully updated essay submission %s.", submissionID)
	respondWithJSON(w, http.StatusOK, updatedSubmission)
}

// DeleteEssaySubmissionHandler handles deleting an essay submission by its ID.
func (h *EssaySubmissionHandlers) DeleteEssaySubmissionHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered DeleteEssaySubmissionHandler")

	vars := mux.Vars(r)
	submissionID, ok := vars["submissionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Submission ID is missing from URL")
		return
	}

	err := h.Service.DeleteEssaySubmission(submissionID)
	if err != nil {
		log.Printf("ERROR: Failed to delete essay submission %s: %v", submissionID, err)
		if err.Error() == "essay submission not found with ID " + submissionID {
			respondWithError(w, http.StatusNotFound, "Essay submission not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to delete essay submission")
		return
	}

	log.Printf("DEBUG: Successfully deleted essay submission %s.", submissionID)
	w.WriteHeader(http.StatusNoContent) // 204 No Content for successful deletion
}
