package handlers

import (
	"api-backend/internal/models"
	"api-backend/internal/services"
	"encoding/json"
	"log"
	"net/http"

	"github.com/gorilla/mux"
)

// EssayQuestionHandlers holds dependencies for essay question-related handlers.
type EssayQuestionHandlers struct {
	Service *services.EssayQuestionService
}

// NewEssayQuestionHandlers creates a new instance of EssayQuestionHandlers.
func NewEssayQuestionHandlers(s *services.EssayQuestionService) *EssayQuestionHandlers {
	return &EssayQuestionHandlers{Service: s}
}

// GetEssayQuestionsByMaterialIDHandler handles fetching all essay questions for a given material.
func (h *EssayQuestionHandlers) GetEssayQuestionsByMaterialIDHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	materialID, ok := vars["materialId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Material ID is missing from URL")
		return
	}

	questions, err := h.Service.GetEssayQuestionsByMaterialID(materialID)
	if err != nil {
		log.Printf("ERROR: Failed to get essay questions for material %s: %v", materialID, err)
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve essay questions")
		return
	}

	respondWithJSON(w, http.StatusOK, questions)
}

// UpdateEssayQuestionHandler handles updating an existing essay question.
func (h *EssayQuestionHandlers) UpdateEssayQuestionHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	questionID, ok := vars["questionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Question ID is missing from URL")
		return
	}

	var req models.UpdateEssayQuestionRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}
	
	updatedQuestion, err := h.Service.UpdateEssayQuestion(questionID, &req)
	if err != nil {
		log.Printf("ERROR: Failed to update essay question %s: %v", questionID, err)
		if err.Error() == "essay question not found" {
			respondWithError(w, http.StatusNotFound, "Essay question not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to update essay question")
		return
	}

	respondWithJSON(w, http.StatusOK, updatedQuestion)
}

// DeleteEssayQuestionHandler handles deleting an essay question by its ID.
func (h *EssayQuestionHandlers) DeleteEssayQuestionHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	questionID, ok := vars["questionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Question ID is missing from URL")
		return
	}

	err := h.Service.DeleteEssayQuestion(questionID)
	if err != nil {
		log.Printf("ERROR: Failed to delete essay question %s: %v", questionID, err)
		// Check for a specific "not found" error from the service
		if err.Error() == "essay question not found with ID "+questionID {
			respondWithError(w, http.StatusNotFound, "Essay question not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to delete essay question")
		return
	}

	w.WriteHeader(http.StatusNoContent) // 204 No Content for successful deletion
}

// GetEssayQuestionByIDHandler handles fetching a single essay question by its ID.
func (h *EssayQuestionHandlers) GetEssayQuestionByIDHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	questionID, ok := vars["questionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Question ID is missing from URL")
		return
	}

	question, err := h.Service.GetEssayQuestionByID(questionID)
	if err != nil {
		log.Printf("ERROR: Failed to get essay question %s: %v", questionID, err)
		if err.Error() == "essay question not found" {
			respondWithError(w, http.StatusNotFound, "Essay question not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve essay question")
		return
	}

	respondWithJSON(w, http.StatusOK, question)
}

