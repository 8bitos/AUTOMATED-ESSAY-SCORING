package handlers

import (
	"api-backend/internal/models"
	"api-backend/internal/services"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"github.com/gorilla/mux"
)

// TeacherReviewHandlers holds dependencies for teacher review-related handlers.
type TeacherReviewHandlers struct {
	Service *services.TeacherReviewService
}

// NewTeacherReviewHandlers creates a new instance of TeacherReviewHandlers.
func NewTeacherReviewHandlers(s *services.TeacherReviewService) *TeacherReviewHandlers {
	return &TeacherReviewHandlers{Service: s}
}

// CreateTeacherReviewHandler handles the creation of a new teacher review.
func (h *TeacherReviewHandlers) CreateTeacherReviewHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered CreateTeacherReviewHandler")

	var req models.CreateTeacherReviewRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	if req.SubmissionID == "" || req.SkorFinal == 0 { // SkorFinal cannot be 0 for creation
		respondWithError(w, http.StatusBadRequest, "Submission ID and Skor Final cannot be empty")
		return
	}

	newReview, err := h.Service.CreateTeacherReview(req.SubmissionID, req.SkorFinal, req.CatatanGuru)
	if err != nil {
		log.Printf("ERROR: Failed to create teacher review in service: %v", err)
		respondWithError(w, http.StatusInternalServerError, "Failed to create teacher review")
		return
	}

	log.Println("DEBUG: Successfully created teacher review, responding with JSON.")
	respondWithJSON(w, http.StatusCreated, newReview)
}

// GetTeacherReviewByIDHandler handles fetching a single teacher review by its ID.
func (h *TeacherReviewHandlers) GetTeacherReviewByIDHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered GetTeacherReviewByIDHandler")

	vars := mux.Vars(r)
	reviewID, ok := vars["reviewId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Review ID is missing from URL")
		return
	}

	review, err := h.Service.GetTeacherReviewByID(reviewID)
	if err != nil {
		log.Printf("ERROR: Failed to get teacher review %s: %v", reviewID, err)
		if err.Error() == "teacher review not found" {
			respondWithError(w, http.StatusNotFound, "Teacher review not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve teacher review")
		return
	}

	log.Printf("DEBUG: Successfully fetched teacher review %s.", reviewID)
	respondWithJSON(w, http.StatusOK, review)
}

// GetTeacherReviewBySubmissionIDHandler handles fetching the teacher review for a specific submission.
func (h *TeacherReviewHandlers) GetTeacherReviewBySubmissionIDHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered GetTeacherReviewBySubmissionIDHandler")

	vars := mux.Vars(r)
	submissionID, ok := vars["submissionId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Submission ID is missing from URL")
		return
	}

	review, err := h.Service.GetTeacherReviewBySubmissionID(submissionID)
	if err != nil {
		log.Printf("ERROR: Failed to get teacher review for submission %s: %v", submissionID, err)
		if err.Error() == fmt.Sprintf("teacher review for submission %s not found", submissionID) {
			respondWithError(w, http.StatusNotFound, "Teacher review for submission not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to retrieve teacher review for submission")
		return
	}

	log.Printf("DEBUG: Successfully fetched teacher review for submission %s.", submissionID)
	respondWithJSON(w, http.StatusOK, review)
}

// UpdateTeacherReviewHandler handles updating an existing teacher review.
func (h *TeacherReviewHandlers) UpdateTeacherReviewHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered UpdateTeacherReviewHandler")

	vars := mux.Vars(r)
	reviewID, ok := vars["reviewId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Review ID is missing from URL")
		return
	}

	var req models.UpdateTeacherReviewRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid request body")
		return
	}

	updatedReview, err := h.Service.UpdateTeacherReview(reviewID, &req)
	if err != nil {
		log.Printf("ERROR: Failed to update teacher review %s: %v", reviewID, err)
		if err.Error() == "teacher review not found for update" {
			respondWithError(w, http.StatusNotFound, "Teacher review not found")
			return
		} else if err.Error() == "no fields to update" {
			respondWithError(w, http.StatusBadRequest, err.Error())
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to update teacher review")
		return
	}

	log.Printf("DEBUG: Successfully updated teacher review %s.", reviewID)
	respondWithJSON(w, http.StatusOK, updatedReview)
}

// DeleteTeacherReviewHandler handles deleting a teacher review by its ID.
func (h *TeacherReviewHandlers) DeleteTeacherReviewHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("DEBUG: Entered DeleteTeacherReviewHandler")

	vars := mux.Vars(r)
	reviewID, ok := vars["reviewId"]
	if !ok {
		respondWithError(w, http.StatusBadRequest, "Review ID is missing from URL")
		return
	}

	err := h.Service.DeleteTeacherReview(reviewID)
	if err != nil {
		log.Printf("ERROR: Failed to delete teacher review %s: %v", reviewID, err)
		if err.Error() == "teacher review not found with ID " + reviewID {
			respondWithError(w, http.StatusNotFound, "Teacher review not found")
			return
		}
		respondWithError(w, http.StatusInternalServerError, "Failed to delete teacher review")
		return
	}

	log.Printf("DEBUG: Successfully deleted teacher review %s.", reviewID)
	w.WriteHeader(http.StatusNoContent) // 204 No Content for successful deletion
}
