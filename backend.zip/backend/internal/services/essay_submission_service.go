package services

import (
	"api-backend/internal/models" // Mengimpor definisi model yang diperlukan (EssaySubmission, GradeEssayRequest, dll.).
	"database/sql"                         // Mengimpor package database/sql untuk interaksi dengan database.
	"fmt"                                  // Mengimpor package fmt untuk format string dan error.
	"strings"                              // Mengimpor package strings untuk manipulasi string (membangun query update).
	"time"                                 // Mengimpor package time untuk timestamp.
)

// EssaySubmissionService menyediakan metode untuk manajemen submission esai.
// Layanan ini juga mengintegrasikan AIService dan EssayQuestionService untuk
// penilaian otomatis dan pengambilan detail pertanyaan.
type EssaySubmissionService struct {
	db                   *sql.DB               // Koneksi database.
	aiService            *AIService            // Referensi ke AIService untuk penilaian AI.
	essayQuestionService *EssayQuestionService // Referensi ke EssayQuestionService untuk mengambil detail pertanyaan.
}

// NewEssaySubmissionService membuat instance baru dari EssaySubmissionService.
// Menerima koneksi database dan referensi ke AIService serta EssayQuestionService.
func NewEssaySubmissionService(db *sql.DB, ai *AIService, eqs *EssayQuestionService) *EssaySubmissionService {
	return &EssaySubmissionService{db: db, aiService: ai, essayQuestionService: eqs}
}

// CreateEssaySubmission membuat submission esai baru di database dan secara otomatis
// memicu penilaian AI untuk esai tersebut.
// Mengembalikan objek EssaySubmission yang baru dibuat dan respons penilaian dari AI.
func (s *EssaySubmissionService) CreateEssaySubmission(questionID, studentID, teksJawaban string) (*models.EssaySubmission, *models.GradeEssayResponse, error) {
	// Membuat objek EssaySubmission baru.
	newSubmission := &models.EssaySubmission{
		QuestionID:  questionID,
		StudentID:   studentID,
		TeksJawaban: teksJawaban,
		SubmittedAt: time.Now(),
	}

	// Query INSERT untuk menambahkan submission esai baru.
	query := `
		INSERT INTO essay_submissions (soal_id, siswa_id, teks_jawaban, submitted_at)
		VALUES ($1, $2, $3, $4)
		RETURNING id
	`

	// Menjalankan query dan memindai ID yang dikembalikan ke newSubmission.ID.
	err := s.db.QueryRow(
		query,
		newSubmission.QuestionID,
		newSubmission.StudentID,
		newSubmission.TeksJawaban,
		newSubmission.SubmittedAt,
	).Scan(&newSubmission.ID)

	if err != nil {
		return nil, nil, fmt.Errorf("error inserting new essay submission: %w", err)
	}

	// Mengambil detail pertanyaan esai yang terkait untuk digunakan dalam penilaian AI.
	question, err := s.essayQuestionService.GetEssayQuestionByID(questionID)
	if err != nil {
		// Mengembalikan submission yang sudah dibuat, tetapi tanpa hasil AI jika gagal mengambil pertanyaan.
		return newSubmission, nil, fmt.Errorf("failed to get essay question for AI grading: %w", err)
	}

	// Mempersiapkan permintaan untuk AIService.
	var idealAnswer, keywords string
	if question.IdealAnswer != nil {
		idealAnswer = *question.IdealAnswer
	}
	// Perhatikan bahwa model EssayQuestion.Keywords adalah *string,
	// tetapi layanan AI mungkin mengharapkan string biasa atau format array.
	// Asumsi saat ini adalah *string perlu di-dereference.
	if question.Keywords != nil {
		keywords = *question.Keywords
	}

	gradeReq := models.GradeEssayRequest{
		Essay:       teksJawaban,
		Question:    question.TeksSoal,
		IdealAnswer: idealAnswer,
		Rubric:      question.Rubric, // Rubrik dari pertanyaan esai.
		Keywords:    keywords,
	}

	// Memanggil AIService untuk menilai esai.
	aiResponse, err := s.aiService.GradeEssay(gradeReq)
	if err != nil {
		fmt.Printf("WARNING: Failed to grade essay with AI for submission %s: %v\n", newSubmission.ID, err)
		// Mengembalikan submission yang sudah dibuat, tetapi dengan error penilaian AI.
		return newSubmission, nil, fmt.Errorf("AI grading failed: %w", err)
	}

	// Mengembalikan submission yang baru dibuat dan respons dari AI.
	return newSubmission, aiResponse, nil
}

// GetEssaySubmissionByID mengambil satu submission esai berdasarkan ID-nya.
func (s *EssaySubmissionService) GetEssaySubmissionByID(submissionID string) (*models.EssaySubmission, error) {
	query := `
		SELECT id, soal_id, siswa_id, teks_jawaban, submitted_at
		FROM essay_submissions
		WHERE id = $1
	`

	var es models.EssaySubmission
	err := s.db.QueryRow(query, submissionID).Scan(
		&es.ID, &es.QuestionID, &es.StudentID, &es.TeksJawaban, &es.SubmittedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("essay submission not found")
		}
		return nil, fmt.Errorf("error querying essay submission %s: %w", submissionID, err)
	}

	return &es, nil
}

// GetEssaySubmissionsByQuestionID mengambil semua submission esai untuk pertanyaan tertentu.
func (s *EssaySubmissionService) GetEssaySubmissionsByQuestionID(questionID string) ([]models.EssaySubmission, error) {
	query := `
		SELECT id, soal_id, siswa_id, teks_jawaban, submitted_at
		FROM essay_submissions
		WHERE soal_id = $1
		ORDER BY submitted_at DESC
	`

	rows, err := s.db.Query(query, questionID)
	if err != nil {
		return nil, fmt.Errorf("error querying essay submissions for question %s: %w", questionID, err)
	}
	defer rows.Close()

	var submissions []models.EssaySubmission
	for rows.Next() {
		var es models.EssaySubmission
		if err := rows.Scan(&es.ID, &es.QuestionID, &es.StudentID, &es.TeksJawaban, &es.SubmittedAt); err != nil {
			return nil, fmt.Errorf("error scanning essay submission row: %w", err)
		}
		submissions = append(submissions, es)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}

	if submissions == nil {
		submissions = []models.EssaySubmission{}
	}

	return submissions, nil
}

// GetEssaySubmissionsByStudentID mengambil semua submission esai oleh siswa tertentu.
func (s *EssaySubmissionService) GetEssaySubmissionsByStudentID(studentID string) ([]models.EssaySubmission, error) {
	query := `
		SELECT id, soal_id, siswa_id, teks_jawaban, submitted_at
		FROM essay_submissions
		WHERE siswa_id = $1
		ORDER BY submitted_at DESC
	`

	rows, err := s.db.Query(query, studentID)
	if err != nil {
		return nil, fmt.Errorf("error querying essay submissions by student %s: %w", studentID, err)
	}
	defer rows.Close()

	var submissions []models.EssaySubmission
	for rows.Next() {
		var es models.EssaySubmission
		if err := rows.Scan(&es.ID, &es.QuestionID, &es.StudentID, &es.TeksJawaban, &es.SubmittedAt); err != nil {
			return nil, fmt.Errorf("error scanning essay submission row: %w", err)
		}
		submissions = append(submissions, es)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}

	if submissions == nil {
		submissions = []models.EssaySubmission{}
	}

	return submissions, nil
}

// UpdateEssaySubmission memperbarui field-field submission esai secara dinamis.
func (s *EssaySubmissionService) UpdateEssaySubmission(submissionID string, updateReq *models.UpdateEssaySubmissionRequest) (*models.EssaySubmission, error) {
	updates := make(map[string]interface{})
	if updateReq.TeksJawaban != nil {
		updates["teks_jawaban"] = *updateReq.TeksJawaban
	}

	if len(updates) == 0 {
		return nil, fmt.Errorf("no fields to update")
	}

	setClauses := []string{}
	args := []interface{}{}
	i := 1
	for k, v := range updates {
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", k, i))
		args = append(args, v)
		i++
	}

	query := fmt.Sprintf("UPDATE essay_submissions SET %s WHERE id = $%d RETURNING id, soal_id, siswa_id, teks_jawaban, submitted_at",
		strings.Join(setClauses, ", "), i)
	args = append(args, submissionID)

	var es models.EssaySubmission
	err := s.db.QueryRow(query, args...).Scan(
		&es.ID, &es.QuestionID, &es.StudentID, &es.TeksJawaban, &es.SubmittedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("essay submission not found for update")
		}
		return nil, fmt.Errorf("error updating essay submission %s: %w", submissionID, err)
	}

	return &es, nil
}

// DeleteEssaySubmission menghapus submission esai berdasarkan ID-nya.
func (s *EssaySubmissionService) DeleteEssaySubmission(submissionID string) error {
	result, err := s.db.Exec("DELETE FROM essay_submissions WHERE id = $1", submissionID)
	if err != nil {
		return fmt.Errorf("error deleting essay submission %s: %w", submissionID, err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("error getting rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return fmt.Errorf("essay submission not found with ID %s", submissionID)
	}

	return nil
}