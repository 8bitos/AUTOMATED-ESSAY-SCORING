package services

import (
	"api-backend/internal/models" // Mengimpor definisi model yang diperlukan (EssayQuestion).
	"context"                              // Mengimpor package context untuk mengelola batas waktu dan pembatalan operasi DB.
	"database/sql"                         // Mengimpor package database/sql untuk interaksi dengan database.
	"fmt"                                  // Mengimpor package fmt untuk format string dan error.
	"strings"                              // Mengimpor package strings untuk manipulasi string (membangun query update).
	"time"                                 // Mengimpor package time untuk timestamp.

	"github.com/lib/pq"                    // Mengimpor driver PostgreSQL khusus untuk fitur array (pq.Array).
)

// EssayQuestionService menyediakan metode untuk manajemen pertanyaan esai.
type EssayQuestionService struct {
	db *sql.DB // Koneksi database yang digunakan oleh layanan ini.
}

// NewEssayQuestionService membuat instance baru dari EssayQuestionService.
// Ini adalah constructor untuk EssayQuestionService.
func NewEssayQuestionService(db *sql.DB) *EssayQuestionService {
	return &EssayQuestionService{db: db}
}

// GetEssayQuestionsByMaterialID mengambil semua pertanyaan esai yang terkait dengan materi tertentu.
func (s *EssayQuestionService) GetEssayQuestionsByMaterialID(materialID string) ([]models.EssayQuestion, error) {
	query := `
		SELECT id, material_id, teks_soal, keywords, ideal_answer, rubric, created_at, updated_at
		FROM essay_questions
		WHERE material_id = $1
		ORDER BY created_at ASC
	`
	rows, err := s.db.QueryContext(context.Background(), query, materialID)
	if err != nil {
		return nil, fmt.Errorf("error querying essay questions for material %s: %w", materialID, err)
	}
	defer rows.Close() // Pastikan baris ditutup setelah selesai.

	var questions []models.EssayQuestion
	for rows.Next() {
		var q models.EssayQuestion
		var keywords sql.NullString // Menggunakan sql.NullString karena 'keywords' bisa NULL di DB.
		if err := rows.Scan(&q.ID, &q.MaterialID, &q.TeksSoal, &keywords, &q.IdealAnswer, &q.Rubric, &q.CreatedAt, &q.UpdatedAt); err != nil {
			return nil, fmt.Errorf("error scanning essay question row: %w", err)
		}
		// Jika keywords tidak NULL, tetapkan ke model.
		if keywords.Valid {
			// Perhatikan bahwa model EssayQuestion.Keywords adalah *string,
			// tetapi di sini kita memindai dari TEXT[] di DB ke string.
			// Ini mungkin perlu penanganan lebih lanjut jika Keywords memang array di DB
			// dan diharapkan sebagai []string di model.
			// Untuk saat ini, kita akan asumsikan ini adalah string yang dipisahkan koma atau representasi array.
			q.Keywords = &keywords.String
		}
		questions = append(questions, q)
	}
	if err = rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}
	if questions == nil {
		questions = []models.EssayQuestion{}
	}
	return questions, nil
}

// UpdateEssayQuestion memperbarui field-field dari pertanyaan esai secara dinamis.
// Menerima ID pertanyaan dan objek UpdateEssayQuestionRequest.
func (s *EssayQuestionService) UpdateEssayQuestion(questionID string, req *models.UpdateEssayQuestionRequest) (*models.EssayQuestion, error) {
    updates := []string{} // Slice untuk menampung klausa SET.
    args := []interface{}{} // Slice untuk menampung argumen query.
    argId := 1 // Counter untuk placeholder ($1, $2, dst.).

    // Membangun klausa SET dan argumen berdasarkan field yang tidak nil di request.
    if req.TeksSoal != nil {
        updates = append(updates, fmt.Sprintf("teks_soal = $%d", argId))
        args = append(args, *req.TeksSoal)
        argId++
    }
    if req.IdealAnswer != nil {
        updates = append(updates, fmt.Sprintf("ideal_answer = $%d", argId))
        args = append(args, *req.IdealAnswer)
        argId++
    }
	if req.Keywords != nil {
		updates = append(updates, fmt.Sprintf("keywords = $%d", argId))
		// Menggunakan pq.Array untuk menyimpan slice string sebagai array di PostgreSQL.
		args = append(args, pq.Array(*req.Keywords))
		argId++
	}
    if req.Rubric != nil {
		updates = append(updates, fmt.Sprintf("rubric = $%d", argId))
		args = append(args, *req.Rubric)
		argId++
	}

    if len(updates) == 0 {
        return nil, fmt.Errorf("no fields to update") // Jika tidak ada field yang perlu diupdate.
    }

	// Menambahkan updated_at secara otomatis.
	updates = append(updates, fmt.Sprintf("updated_at = $%d", argId))
	args = append(args, time.Now())
	argId++

    args = append(args, questionID) // Menambahkan ID pertanyaan sebagai argumen terakhir.
    // Membangun query UPDATE lengkap.
    query := fmt.Sprintf("UPDATE essay_questions SET %s WHERE id = $%d", strings.Join(updates, ", "), argId)

    _, err := s.db.ExecContext(context.Background(), query, args...)
    if err != nil {
        return nil, fmt.Errorf("error updating essay question: %w", err)
    }

    // Mengambil dan mengembalikan pertanyaan yang sudah diperbarui.
    return s.GetEssayQuestionByID(questionID) // Asumsi GetEssayQuestionByID sudah ada dan berfungsi.
}

// GetEssayQuestionByID mengambil satu pertanyaan esai berdasarkan ID-nya.
func (s *EssayQuestionService) GetEssayQuestionByID(questionID string) (*models.EssayQuestion, error) {
	query := `
		SELECT id, material_id, teks_soal, keywords, ideal_answer, rubric, created_at, updated_at
		FROM essay_questions
		WHERE id = $1
	`
	var q models.EssayQuestion
	var keywords sql.NullString // Menggunakan sql.NullString karena 'keywords' bisa NULL di DB.
	err := s.db.QueryRowContext(context.Background(), query, questionID).Scan(
		&q.ID, &q.MaterialID, &q.TeksSoal, &keywords, &q.IdealAnswer, &q.Rubric, &q.CreatedAt, &q.UpdatedAt,
	)
	// Jika keywords tidak NULL, tetapkan ke model.
	if keywords.Valid {
		q.Keywords = &keywords.String
	}
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("essay question not found")
		}
		return nil, fmt.Errorf("error querying essay question %s: %w", questionID, err)
	}
	return &q, nil
}

// DeleteEssayQuestion menghapus pertanyaan esai berdasarkan ID-nya.
func (s *EssayQuestionService) DeleteEssayQuestion(questionID string) error {
	result, err := s.db.ExecContext(context.Background(), "DELETE FROM essay_questions WHERE id = $1", questionID)
	if err != nil {
		return fmt.Errorf("error deleting essay question %s: %w", questionID, err)
	}
	rowsAffected, _ := result.RowsAffected() // Mengabaikan error dari RowsAffected().
	if rowsAffected == 0 {
		return fmt.Errorf("essay question not found with ID %s", questionID) // Jika tidak ada baris yang terpengaruh.
	}
	return nil
}