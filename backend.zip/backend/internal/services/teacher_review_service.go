package services

import (
	"api-backend/internal/models" // Mengimpor definisi model TeacherReview.
	"database/sql"                         // Mengimpor package database/sql untuk interaksi dengan database.
	"fmt"                                  // Mengimpor package fmt untuk format string dan error.
	"strings"                              // Mengimpor package strings untuk manipulasi string (membangun query update).
	"time"                                 // Mengimpor package time untuk timestamp.
)

// TeacherReviewService menyediakan metode untuk manajemen review guru terhadap submission esai.
type TeacherReviewService struct {
	db *sql.DB // Koneksi database yang digunakan oleh layanan ini.
}

// NewTeacherReviewService membuat instance baru dari TeacherReviewService.
// Ini adalah constructor untuk TeacherReviewService.
func NewTeacherReviewService(db *sql.DB) *TeacherReviewService {
	return &TeacherReviewService{db: db}
}

// CreateTeacherReview membuat review guru baru di database untuk submission esai tertentu.
func (s *TeacherReviewService) CreateTeacherReview(submissionID string, skorFinal float64, catatanGuru *string) (*models.TeacherReview, error) {
	// Membuat objek TeacherReview baru dari parameter.
	newReview := &models.TeacherReview{
		SubmissionID: submissionID,
		SkorFinal:    skorFinal,
		CatatanGuru:  catatanGuru, // Nilai pointer bisa nil.
		ReviewedAt:   time.Now(),  // Mengatur timestamp saat review dibuat.
	}

	// Query INSERT untuk menambahkan review guru baru.
	query := `
		INSERT INTO teacher_reviews (submission_id, skor_final, catatan_guru, reviewed_at)
		VALUES ($1, $2, $3, $4)
		RETURNING id
	`

	// Menjalankan query dan memindai ID yang dikembalikan ke newReview.ID.
	err := s.db.QueryRow(
		query,
		newReview.SubmissionID,
		newReview.SkorFinal,
		newReview.CatatanGuru,
		newReview.ReviewedAt,
	).Scan(&newReview.ID)

	if err != nil {
		return nil, fmt.Errorf("error inserting new teacher review: %w", err)
	}

	return newReview, nil
}

// GetTeacherReviewByID mengambil satu review guru berdasarkan ID-nya.
func (s *TeacherReviewService) GetTeacherReviewByID(reviewID string) (*models.TeacherReview, error) {
	query := `
		SELECT id, submission_id, skor_final, catatan_guru, reviewed_at
		FROM teacher_reviews
		WHERE id = $1
	`

	var tr models.TeacherReview // Objek untuk menampung hasil query.
	// Menjalankan query dan memindai hasilnya.
	err := s.db.QueryRow(query, reviewID).Scan(
		&tr.ID, &tr.SubmissionID, &tr.SkorFinal, &tr.CatatanGuru, &tr.ReviewedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("teacher review not found")
		}
		return nil, fmt.Errorf("error querying teacher review %s: %w", reviewID, err)
	}

	return &tr, nil
}

// GetTeacherReviewBySubmissionID mengambil review guru untuk submission esai tertentu.
func (s *TeacherReviewService) GetTeacherReviewBySubmissionID(submissionID string) (*models.TeacherReview, error) {
	query := `
		SELECT id, submission_id, skor_final, catatan_guru, reviewed_at
		FROM teacher_reviews
		WHERE submission_id = $1
	`

	var tr models.TeacherReview
	// Menjalankan query dan memindai hasilnya.
	err := s.db.QueryRow(query, submissionID).Scan(
		&tr.ID, &tr.SubmissionID, &tr.SkorFinal, &tr.CatatanGuru, &tr.ReviewedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("teacher review for submission %s not found", submissionID)
		}
		return nil, fmt.Errorf("error querying teacher review for submission %s: %w", submissionID, err)
	}

	return &tr, nil
}

// UpdateTeacherReview memperbarui review guru yang sudah ada.
// Menerima ID review dan permintaan update (UpdateTeacherReviewRequest).
func (s *TeacherReviewService) UpdateTeacherReview(reviewID string, updateReq *models.UpdateTeacherReviewRequest) (*models.TeacherReview, error) {
	updates := make(map[string]interface{}) // Map untuk menampung field yang akan diupdate.
	// Memeriksa field mana yang ada di updateReq dan menambahkannya ke map updates.
	if updateReq.SkorFinal != nil {
		updates["skor_final"] = *updateReq.SkorFinal
	}
	if updateReq.CatatanGuru != nil {
		updates["catatan_guru"] = *updateReq.CatatanGuru
	}

	if len(updates) == 0 {
		return nil, fmt.Errorf("no fields to update") // Jika tidak ada field yang perlu diupdate.
	}

	setClauses := []string{} // Slice untuk menampung klausa SET query SQL.
	args := []interface{}{}  // Slice untuk menampung argumen query SQL.
	i := 1                   // Counter untuk placeholder query ($1, $2, dst.).
	for k, v := range updates {
		setClauses = append(setClauses, fmt.Sprintf("%s = $%d", k, i)) // Menambahkan klausa SET.
		args = append(args, v)                                        // Menambahkan nilai argumen.
		i++
	}

	// Membangun query UPDATE secara dinamis.
	query := fmt.Sprintf("UPDATE teacher_reviews SET %s WHERE id = $%d RETURNING id, submission_id, skor_final, catatan_guru, reviewed_at",
		strings.Join(setClauses, ", "), i) // Menggabungkan klausa SET.
	args = append(args, reviewID) // Menambahkan ID review sebagai argumen terakhir.

	var tr models.TeacherReview
	// Menjalankan query UPDATE dan memindai hasilnya yang diperbarui.
	err := s.db.QueryRow(query, args...).Scan(
		&tr.ID, &tr.SubmissionID, &tr.SkorFinal, &tr.CatatanGuru, &tr.ReviewedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("teacher review not found for update") // Review guru tidak ditemukan saat update.
		}
		return nil, fmt.Errorf("error updating teacher review %s: %w", reviewID, err) // Error update lainnya.
	}

	return &tr, nil
}

// DeleteTeacherReview menghapus review guru berdasarkan ID-nya.
func (s *TeacherReviewService) DeleteTeacherReview(reviewID string) error {
	// Menjalankan query DELETE.
	result, err := s.db.Exec("DELETE FROM teacher_reviews WHERE id = $1", reviewID)
	if err != nil {
		return fmt.Errorf("error deleting teacher review %s: %w", reviewID, err)
	}

	// Memeriksa berapa banyak baris yang terpengaruh oleh query DELETE.
	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("error getting rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return fmt.Errorf("teacher review not found with ID %s", reviewID) // Jika tidak ada baris yang terhapus.
	}

	return nil
}