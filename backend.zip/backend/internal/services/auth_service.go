package services

import (
	"api-backend/internal/models" // Mengimpor definisi model pengguna.
	"database/sql"                         // Mengimpor package database/sql untuk interaksi DB.
	"fmt"                                  // Mengimpor package fmt untuk format string dan error.
	"log"                                  // Mengimpor package log untuk logging.
	"time"                                 // Mengimpor package time untuk timestamp.

	"golang.org/x/crypto/bcrypt"           // Mengimpor bcrypt untuk hashing password.
)

// AuthService menyediakan metode untuk otentikasi dan registrasi pengguna.
type AuthService struct {
	db *sql.DB // Koneksi database yang digunakan oleh layanan ini.
}

// NewAuthService membuat instance baru dari AuthService.
// Ini adalah constructor untuk AuthService, menerima koneksi *sql.DB.
func NewAuthService(db *sql.DB) *AuthService {
	return &AuthService{db: db}
}

// AuthenticateUser memverifikasi kredensial pengguna (email/username dan password).
// Mengembalikan objek User jika kredensial valid, atau error jika tidak.
func (s *AuthService) AuthenticateUser(identifier, password string) (*models.User, error) {
	user := &models.User{} // Inisialisasi objek User untuk menampung hasil query.
	// Query untuk mengambil data pengguna berdasarkan email atau username.
	query := `SELECT id, nama_lengkap, email, password, peran, username, nomor_identitas, created_at FROM users WHERE email = $1 OR username = $1`

	// Variabel sql.NullString digunakan untuk menangani kolom database yang bisa NULL.
	var username sql.NullString
	var nomorIdentitas sql.NullString

	// Menjalankan query dan memindai hasilnya ke dalam field-field objek user.
	err := s.db.QueryRow(query, identifier).Scan(
		&user.ID,
		&user.NamaLengkap,
		&user.Email,
		&user.Password, // Password yang sudah di-hash dari DB.
		&user.Peran,
		&username,      // Hasil scan untuk username yang bisa NULL.
		&nomorIdentitas, // Hasil scan untuk nomor_identitas yang bisa NULL.
		&user.CreatedAt,
	)

	// Menangani kasus jika pengguna tidak ditemukan.
	if err == sql.ErrNoRows {
		return nil, fmt.Errorf("invalid credentials")
	}
	// Menangani error lain saat query database.
	if err != nil {
		return nil, fmt.Errorf("error querying user: %w", err)
	}

	// Mengonversi sql.NullString ke tipe *string untuk model pengguna.
	if username.Valid {
		user.Username = &username.String
	}
	if nomorIdentitas.Valid {
		user.NomorIdentitas = &nomorIdentitas.String
	}

	// Membandingkan password yang diberikan pengguna dengan password yang di-hash di database.
	err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password))
	if err != nil {
		return nil, fmt.Errorf("invalid credentials") // Password tidak cocok.
	}

	// Kosongkan password dari objek user sebelum dikembalikan untuk keamanan.
	user.Password = ""
	return user, nil
}

// RegisterUser membuat pengguna baru di database dari data permintaan registrasi.
// Mengembalikan objek User yang baru dibuat, atau error jika ada masalah (misalnya, email/username sudah ada).
func (s *AuthService) RegisterUser(req models.UserRegisterRequest) (*models.User, error) {
	// Memeriksa apakah email atau username sudah terdaftar.
	var count int
	err := s.db.QueryRow("SELECT COUNT(*) FROM users WHERE email = $1 OR username = $2", req.Email, req.Username).Scan(&count)
	if err != nil {
		log.Printf("ERROR: Failed to check for existing user: %v", err)
		return nil, fmt.Errorf("error checking for existing user: %w", err)
	}
	if count > 0 {
		return nil, fmt.Errorf("email or username already exists") // Jika sudah ada, kembalikan error.
	}

	// Meng-hash password yang diberikan pengguna.
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		log.Printf("ERROR: Failed to hash password: %v", err)
		return nil, fmt.Errorf("error hashing password: %w", err)
	}

	// Membuat objek User baru dengan data dari permintaan.
	newUser := &models.User{
		NamaLengkap: req.NamaLengkap,
		Email:       req.Email,
		Password:    string(hashedPassword), // Simpan password yang sudah di-hash.
		Peran:       req.Peran,
		CreatedAt:   time.Now(),
	}

	// Menangani field username dan nomor_identitas yang bersifat nullable.
	if req.Username != "" {
		newUser.Username = &req.Username
	}
	if req.NomorIdentitas != "" {
		newUser.NomorIdentitas = &req.NomorIdentitas
	}

	// Query INSERT untuk menambahkan pengguna baru ke tabel 'users'.
	query := `
		INSERT INTO users (nama_lengkap, email, password, peran, username, nomor_identitas, created_at)
		VALUES ($1, $2, $3, $4, $5, $6, $7)
		RETURNING id, created_at
	`
	// Menjalankan query dan mengembalikan ID serta CreatedAt dari pengguna yang baru dibuat.
	err = s.db.QueryRow(query,
		newUser.NamaLengkap,
		newUser.Email,
		newUser.Password,
		newUser.Peran,
		newUser.Username,
		newUser.NomorIdentitas,
		newUser.CreatedAt,
	).Scan(&newUser.ID, &newUser.CreatedAt)

	if err != nil {
		log.Printf("ERROR: Failed to insert new user: %v", err)
		return nil, fmt.Errorf("error inserting new user: %w", err)
	}
	
	// Kosongkan password dari objek user sebelum dikembalikan untuk keamanan.
	newUser.Password = ""
	return newUser, nil
}

// GetUserByID mengambil detail pengguna berdasarkan ID mereka.
// Mengembalikan objek User atau error jika pengguna tidak ditemukan atau ada error DB.
func (s *AuthService) GetUserByID(userID string) (*models.User, error) {
	user := &models.User{} // Inisialisasi objek User.
	// Query untuk mengambil data pengguna berdasarkan ID.
	query := `SELECT id, nama_lengkap, email, peran, nomor_identitas, username, created_at FROM users WHERE id = $1`

	// Variabel sql.NullString untuk menangani kolom yang bisa NULL.
	var username sql.NullString
	var nomorIdentitas sql.NullString

	// Menjalankan query dan memindai hasilnya.
	err := s.db.QueryRow(query, userID).Scan(
		&user.ID,
		&user.NamaLengkap,
		&user.Email,
		&user.Peran,
		&nomorIdentitas,
		&username,
		&user.CreatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("user not found") // Pengguna tidak ditemukan.
		}
		return nil, fmt.Errorf("error querying user by id: %w", err) // Error query lainnya.
	}

	// Mengonversi sql.NullString ke tipe *string untuk model pengguna.
	if username.Valid {
		user.Username = &username.String
	}
	if nomorIdentitas.Valid {
		user.NomorIdentitas = &nomorIdentitas.String
	}

	return user, nil
}