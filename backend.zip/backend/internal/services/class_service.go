package services

import (
	"api-backend/internal/models" // Mengimpor definisi model yang diperlukan (Class, CreateClassRequest, dll.).
	"context"                              // Mengimpor package context untuk mengelola batas waktu dan pembatalan operasi DB.
	"database/sql"                         // Mengimpor package database/sql untuk interaksi dengan database.
	"fmt"                                  // Mengimpor package fmt untuk format string dan error.
	"time"                                 // Mengimpor package time untuk timestamp.
)

// ClassService menyediakan metode untuk manajemen kelas (CRUD) dan keanggotaan kelas.
// Layanan ini juga berinteraksi dengan MaterialService dan EssayQuestionService
// untuk mengambil data terkait materi dan pertanyaan esai dalam suatu kelas.
type ClassService struct {
	db                  *sql.DB               // Koneksi database.
	materialService     *MaterialService      // Referensi ke MaterialService untuk mengambil materi.
	essayQuestionService *EssayQuestionService // Referensi ke EssayQuestionService untuk mengambil pertanyaan esai.
}

// NewClassService membuat instance baru dari ClassService.
// Menerima koneksi database dan referensi ke layanan materi serta pertanyaan esai.
func NewClassService(db *sql.DB, ms *MaterialService, eqs *EssayQuestionService) *ClassService {
	return &ClassService{db: db, materialService: ms, essayQuestionService: eqs}
}

// CreateClass membuat kelas baru di database.
// Hanya guru yang dapat membuat kelas.
func (s *ClassService) CreateClass(req models.CreateClassRequest, userID string) (*models.Class, error) {
	// Inisialisasi objek Class baru dengan data dari request dan ID guru.
	newClass := &models.Class{
		TeacherID:   userID,
		ClassName:   req.ClassName,
		Description: req.Description,
		ClassCode:   models.GenerateClassCode(), // Menghasilkan kode kelas unik.
		CreatedAt:   time.Now(),
		UpdatedAt:   time.Now(),
	}

	// Query INSERT untuk menambahkan kelas baru ke tabel `classes`.
	query := `
		INSERT INTO classes (teacher_id, class_name, deskripsi, class_code, created_at, updated_at)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING id, created_at, updated_at
	`
	// Menjalankan query dan memindai ID, CreatedAt, UpdatedAt yang dikembalikan.
	err := s.db.QueryRowContext(context.Background(),
		query,
		newClass.TeacherID,
		newClass.ClassName,
		newClass.Description,
		newClass.ClassCode,
		newClass.CreatedAt,
		newClass.UpdatedAt,
	).Scan(&newClass.ID, &newClass.CreatedAt, &newClass.UpdatedAt)

	if err != nil {
		return nil, fmt.Errorf("error inserting new class: %w", err)
	}

	return newClass, nil
}

// GetClasses mengambil semua kelas yang dibuat oleh guru tertentu.
func (s *ClassService) GetClasses(teacherID string) ([]models.Class, error) {
	query := `
		SELECT id, teacher_id, class_name, deskripsi, class_code, created_at, updated_at
		FROM classes
		WHERE teacher_id = $1
		ORDER BY created_at DESC
	`
	rows, err := s.db.QueryContext(context.Background(), query, teacherID)
	if err != nil {
		return nil, fmt.Errorf("error querying classes for teacher %s: %w", teacherID, err)
	}
	defer rows.Close() // Pastikan baris ditutup setelah selesai.

	var classes []models.Class
	for rows.Next() {
		var c models.Class
		if err := rows.Scan(
			&c.ID, &c.TeacherID, &c.ClassName, &c.Description, &c.ClassCode, &c.CreatedAt, &c.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("error scanning class row: %w", err)
		}
		classes = append(classes, c)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}
	// Mengembalikan slice kosong jika tidak ada kelas ditemukan, bukan nil.
	if classes == nil {
		classes = []models.Class{}
	}
	return classes, nil
}

// GetAllClasses mengambil semua kelas yang tersedia.
// Ini adalah endpoint publik yang mungkin digunakan untuk development atau tampilan awal.
func (s *ClassService) GetAllClasses() ([]models.Class, error) {
	query := `
		SELECT id, teacher_id, class_name, deskripsi, class_code, created_at, updated_at
		FROM classes
		ORDER BY created_at DESC
	`
	rows, err := s.db.QueryContext(context.Background(), query)
	if err != nil {
		return nil, fmt.Errorf("error querying all classes: %w", err)
	}
	defer rows.Close()

	var classes []models.Class
	for rows.Next() {
		var c models.Class
		if err := rows.Scan(
			&c.ID, &c.TeacherID, &c.ClassName, &c.Description, &c.ClassCode, &c.CreatedAt, &c.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("error scanning class row: %w", err)
		}
		classes = append(classes, c)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}
	if classes == nil {
		classes = []models.Class{}
	}
	return classes, nil
}

// GetClassByID retrieves a single class by its ID.
func (s *ClassService) GetClassByID(classID string) (*models.Class, error) {
	query := `
		SELECT id, teacher_id, class_name, deskripsi, class_code, created_at, updated_at
		FROM classes
		WHERE id = $1
	`
	var c models.Class
	err := s.db.QueryRowContext(context.Background(), query, classID).Scan(
		&c.ID, &c.TeacherID, &c.ClassName, &c.Description, &c.ClassCode, &c.CreatedAt, &c.UpdatedAt,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("class not found")
		}
		return nil, fmt.Errorf("error querying class %s: %w", classID, err)
	}
	return &c, nil
}

// GetStudentsByClassID retrieves all students who are members of a specific class.
// Mengembalikan slice ClassMember dengan nama dan email siswa yang denormalized.
func (s *ClassService) GetStudentsByClassID(classID string) ([]models.ClassMember, error) {
	query := `
		SELECT cm.id, u.nama_lengkap, u.email, cm.joined_at
		FROM users u
		JOIN class_members cm ON u.id = cm.user_id
		WHERE cm.class_id = $1
		ORDER BY u.nama_lengkap ASC
	`
	rows, err := s.db.QueryContext(context.Background(), query, classID)
	if err != nil {
		return nil, fmt.Errorf("error querying students for class %s: %w", classID, err)
	}
	defer rows.Close()

	var members []models.ClassMember
	for rows.Next() {
		var cm models.ClassMember
		if err := rows.Scan(&cm.ID, &cm.StudentName, &cm.StudentEmail, &cm.JoinedAt); err != nil {
			return nil, fmt.Errorf("error scanning class member row: %w", err)
		}
		members = append(members, cm)
	}
	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}
	if members == nil {
		members = []models.ClassMember{}
	}
	return members, nil
}

// RemoveStudentFromClass menghapus seorang siswa dari sebuah kelas.
func (s *ClassService) RemoveStudentFromClass(classID, studentID string) error {
	_, err := s.db.ExecContext(context.Background(), "DELETE FROM class_members WHERE class_id = $1 AND user_id = $2", classID, studentID)
	if err != nil {
		return fmt.Errorf("error deleting class member: %w", err)
	}
	return nil
}

// JoinClass menambahkan seorang siswa ke sebuah kelas menggunakan kode kelas.
func (s *ClassService) JoinClass(classCode, studentID string) error {
	var classID string
	// 1. Temukan ID Kelas berdasarkan Kode Kelas.
	err := s.db.QueryRowContext(context.Background(), "SELECT id FROM classes WHERE class_code = $1", classCode).Scan(&classID)
	if err != nil {
		if err == sql.ErrNoRows {
			return fmt.Errorf("class not found") // Kelas tidak ditemukan.
		}
		return fmt.Errorf("error finding class by code: %w", err)
	}

	// 2. Periksa Keanggotaan yang Sudah Ada.
	var existingMemberID string
	err = s.db.QueryRowContext(context.Background(), "SELECT id FROM class_members WHERE class_id = $1 AND user_id = $2", classID, studentID).Scan(&existingMemberID)
	if err == nil {
		return fmt.Errorf("student is already a member of this class") // Siswa sudah menjadi anggota.
	}
	// Jika error bukan sql.ErrNoRows, berarti ada masalah lain saat memeriksa.
	if err != nil && err != sql.ErrNoRows {
		return fmt.Errorf("error checking existing membership: %w", err)
	}

	// 3. Masukkan Keanggotaan Baru.
	query := `
		INSERT INTO class_members (class_id, user_id, joined_at)
		VALUES ($1, $2, $3)
	`
	_, err = s.db.ExecContext(context.Background(), query, classID, studentID, time.Now())
	if err != nil {
		return fmt.Errorf("error inserting new class member: %w", err)
	}

	return nil
}

// GetStudentClasses retrieves all classes a student is a member of,
// along with their materials and essay questions.
// Ini adalah operasi yang kompleks karena menggabungkan data dari beberapa layanan.
func (s *ClassService) GetStudentClasses(studentID string) ([]models.Class, error) {
	query := `
		SELECT
			c.id, c.teacher_id, c.class_name, c.deskripsi, c.class_code, c.created_at, c.updated_at
		FROM classes c
		JOIN class_members cm ON c.id = cm.class_id
		WHERE cm.user_id = $1
		ORDER BY c.created_at DESC
	`
	rows, err := s.db.QueryContext(context.Background(), query, studentID)
	if err != nil {
		return nil, fmt.Errorf("error querying classes for student %s: %w", studentID, err)
	}
	defer rows.Close()

	var classes []models.Class
	for rows.Next() {
		var c models.Class
		if err := rows.Scan(
			&c.ID, &c.TeacherID, &c.ClassName, &c.Description, &c.ClassCode, &c.CreatedAt, &c.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("error scanning class row for student classes: %w", err)
		}

		// Ambil materi untuk kelas saat ini menggunakan MaterialService.
		materials, err := s.materialService.GetMaterialsForStudentByClassID(c.ID, studentID)
		if err != nil {
			// Log error, tetapi jangan gagalkan seluruh permintaan; kembalikan slice materi kosong.
			fmt.Printf("WARNING: Failed to fetch materials for class %s (student %s): %v\n", c.ID, studentID, err)
			materials = []models.Material{}
		}

		// Ambil pertanyaan esai untuk setiap materi menggunakan EssayQuestionService.
		for i := range materials {
			questions, err := s.essayQuestionService.GetEssayQuestionsByMaterialID(materials[i].ID)
			if err != nil {
				fmt.Printf("WARNING: Failed to fetch essay questions for material %s: %v\n", materials[i].ID, err)
				questions = []models.EssayQuestion{}
			}
			materials[i].EssayQuestions = questions
		}
		c.Materials = materials // Tetapkan materi ke kelas.
		classes = append(classes, c)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error during rows iteration: %w", err)
	}
	if classes == nil {
		classes = []models.Class{}
	}
	return classes, nil
}

// GetStudentClassDetails retrieves a single class with its materials and essay questions for a student,
// ensuring the student is a member of that class.
func (s *ClassService) GetStudentClassDetails(classID, studentID string) (*models.Class, error) {
	// 1. Periksa Keanggotaan Siswa.
	var memberID string
	err := s.db.QueryRowContext(context.Background(),
		"SELECT id FROM class_members WHERE class_id = $1 AND user_id = $2",
		classID, studentID).Scan(&memberID)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("class not found or student not a member")
		}
		return nil, fmt.Errorf("error checking student membership for class %s: %w", classID, err)
	}

	// 2. Ambil Detail Kelas.
	query := `
		SELECT
			id, teacher_id, class_name, deskripsi, class_code, created_at, updated_at
		FROM classes
		WHERE id = $1
	`
	var cls models.Class
	err = s.db.QueryRowContext(context.Background(), query, classID).Scan(
		&cls.ID, &cls.TeacherID, &cls.ClassName, &cls.Description, &cls.ClassCode, &cls.CreatedAt, &cls.UpdatedAt,
	)
	if err != nil {
		if err == sql.ErrNoRows {
			return nil, fmt.Errorf("class not found or student not a member")
		}
		return nil, fmt.Errorf("error querying class %s: %w", classID, err)
	}

	// 3. Ambil Materi untuk kelas menggunakan MaterialService.
	materials, err := s.materialService.GetMaterialsForStudentByClassID(cls.ID, studentID)
	if err != nil {
		fmt.Printf("WARNING: Failed to fetch materials for class %s (student %s): %v\n", cls.ID, studentID, err)
		materials = []models.Material{}
	}

	// 4. Ambil pertanyaan esai untuk setiap materi menggunakan EssayQuestionService.
	for i := range materials {
		questions, err := s.essayQuestionService.GetEssayQuestionsByMaterialID(materials[i].ID)
		if err != nil {
			fmt.Printf("WARNING: Failed to fetch essay questions for material %s: %v\n", materials[i].ID, err)
			questions = []models.EssayQuestion{}
		}
		materials[i].EssayQuestions = questions
	}
	cls.Materials = materials // Tetapkan materi ke objek kelas.

	return &cls, nil
}