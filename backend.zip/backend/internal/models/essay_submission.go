package models

import (
	"time" // Mengimpor package time untuk timestamp.
)

// EssaySubmission merepresentasikan submission esai seorang siswa untuk sebuah pertanyaan esai.
// Struktur ini berkorespondensi dengan tabel `essay_submissions` di database.
type EssaySubmission struct {
	ID          string    `json:"id"`           // ID unik submission esai, biasanya UUID.
	QuestionID  string    `json:"question_id"`  // ID pertanyaan esai yang dijawab (Foreign Key ke tabel essay_questions).
	StudentID   string    `json:"student_id"`   // ID siswa yang membuat submission (Foreign Key ke tabel users).
	TeksJawaban string    `json:"teks_jawaban"` // Teks jawaban esai yang disubmit.
	SubmittedAt time.Time `json:"submitted_at"` // Timestamp ketika esai disubmit.
}

// CreateEssaySubmissionRequest mendefinisikan struktur data untuk permintaan
// pembuatan submission esai baru oleh siswa.
type CreateEssaySubmissionRequest struct {
	QuestionID  string `json:"question_id"`  // ID pertanyaan esai yang dijawab.
	TeksJawaban string `json:"teks_jawaban"` // Teks jawaban esai.
}

// UpdateEssaySubmissionRequest mendefinisikan field-field yang dapat diperbarui
// untuk sebuah submission esai. Semua field bersifat opsional (omitempty).
type UpdateEssaySubmissionRequest struct {
	TeksJawaban *string `json:"teks_jawaban,omitempty"` // Pointer ke string untuk teks jawaban (opsional).
}