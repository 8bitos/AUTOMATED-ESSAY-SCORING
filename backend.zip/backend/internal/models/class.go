package models

import (
	"math/rand" // Mengimpor package rand untuk menghasilkan angka acak.
	"time"       // Mengimpor package time untuk fungsi terkait waktu (digunakan untuk seeding rand).
)

// Class merepresentasikan sebuah kelas atau kursus dalam sistem.
// Struktur ini berkorespondensi dengan tabel `classes` di database.
type Class struct {
	ID          string    `json:"id"`          // ID unik kelas, biasanya UUID.
	TeacherID   string    `json:"pengajar_id"` // ID pengguna yang mengajar kelas ini (Foreign Key ke tabel users).
	ClassName   string    `json:"class_name"`  // Nama kelas (misalnya, "Matematika Dasar").
	Description string    `json:"deskripsi"`   // Deskripsi singkat tentang kelas.
	ClassCode   string    `json:"class_code"`  // Kode unik kelas untuk bergabung.
	CreatedAt   time.Time `json:"created_at"`  // Timestamp ketika kelas dibuat.
	UpdatedAt   time.Time `json:"updated_at"`  // Timestamp terakhir kali kelas diperbarui.
	Materials   []Material `json:"materials,omitempty"` // Daftar materi yang terkait dengan kelas ini (opsional untuk output JSON).
}

// CreateClassRequest mendefinisikan struktur data untuk permintaan pembuatan kelas baru.
// Ini adalah data yang diharapkan diterima dari client saat membuat kelas.
type CreateClassRequest struct {
	ClassName   string `json:"nama_kelas"` // Nama kelas yang akan dibuat.
	Description string `json:"deskripsi"`  // Deskripsi kelas.
}

// JoinClassRequest mendefinisikan struktur data untuk permintaan bergabung ke kelas.
// Pengguna perlu menyediakan kode kelas untuk bergabung.
type JoinClassRequest struct {
	ClassCode string `json:"class_code"` // Kode kelas yang ingin diikuti.
}

// GenerateClassCode menghasilkan kode kelas alfanumerik unik dengan panjang 6 karakter.
// Kode ini digunakan agar siswa dapat bergabung ke kelas.
func GenerateClassCode() string {
	const charset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789" // Karakter yang diizinkan untuk kode kelas.
	// Menginisialisasi generator angka acak dengan seed berdasarkan waktu saat ini
	// untuk memastikan kode yang dihasilkan unik setiap kali.
	seededRand := rand.New(rand.NewSource(time.Now().UnixNano()))
	b := make([]byte, 6) // Membuat slice byte sepanjang 6 untuk menampung kode.
	for i := range b {
		// Mengisi setiap posisi dengan karakter acak dari charset.
		b[i] = charset[seededRand.Intn(len(charset))]
	}
	return string(b) // Mengembalikan kode kelas sebagai string.
}
