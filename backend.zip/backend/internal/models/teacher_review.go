package models

import (
	"time" // Mengimpor package time untuk timestamp.
)

// TeacherReview merepresentasikan review akhir dan skor yang diberikan oleh guru
// untuk sebuah submission esai siswa.
// Struktur ini berkorespondensi dengan tabel `teacher_reviews` di database.
type TeacherReview struct {
	ID           string    `json:"id"`            // ID unik review guru, biasanya UUID.
	SubmissionID string    `json:"submission_id"` // ID submission esai yang di-review (Foreign Key ke tabel essay_submissions).
	SkorFinal    float64   `json:"skor_final"`    // Skor akhir yang diberikan oleh guru.
	CatatanGuru  *string   `json:"catatan_guru,omitempty"` // Catatan atau umpan balik dari guru (opsional, bisa NULL).
	ReviewedAt   time.Time `json:"reviewed_at"`   // Timestamp ketika review ini dibuat.
}

// CreateTeacherReviewRequest mendefinisikan struktur data untuk permintaan
// pembuatan review guru baru.
type CreateTeacherReviewRequest struct {
	SubmissionID string  `json:"submission_id"`  // ID submission esai yang akan di-review.
	SkorFinal    float64 `json:"skor_final"`     // Skor akhir yang diberikan.
	CatatanGuru  *string `json:"catatan_guru,omitempty"` // Catatan guru (opsional).
}

// UpdateTeacherReviewRequest mendefinisikan struktur data untuk permintaan
// pembaruan review guru yang sudah ada.
// Semua field bersifat opsional (pointer dan omitempty) karena tidak semua field mungkin diperbarui.
type UpdateTeacherReviewRequest struct {
	SkorFinal   *float64 `json:"skor_final,omitempty"`   // Pointer ke float64 untuk skor final (opsional).
	CatatanGuru *string  `json:"catatan_guru,omitempty"` // Pointer ke string untuk catatan guru (opsional).
}