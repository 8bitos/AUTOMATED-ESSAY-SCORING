package models

import (
	"github.com/golang-jwt/jwt/v5" // Mengimpor package JWT untuk definisi klaim.
	"time"                         // Mengimpor package time untuk timestamp.
)

// Claims merepresentasikan data yang disimpan dalam token JWT (JSON Web Token).
// Data ini digunakan untuk otentikasi dan otorisasi pengguna.
type Claims struct {
	UserID   string `json:"user_id"`   // ID unik pengguna.
	UserName string `json:"user_name"` // Nama pengguna.
	UserRole string `json:"user_role"` // Peran pengguna (misalnya, student, teacher, superadmin).
	jwt.RegisteredClaims            // Klaim standar JWT seperti Issuer, Subject, Audience, Expiration, dll.
}

// User merepresentasikan sebuah entitas pengguna dalam sistem,
// yang berkorespondensi langsung dengan tabel 'users' di database.
type User struct {
	ID             string    `json:"id"`                          // ID unik pengguna, biasanya UUID.
	NamaLengkap    string    `json:"nama_lengkap"`                // Nama lengkap pengguna.
	Email          string    `json:"email"`                       // Alamat email pengguna, harus unik.
	Password       string    `json:"-"`                           // Password pengguna (hashed). Tag "-" mengecualikannya dari output JSON.
	Peran          string    `json:"peran"`                       // Peran pengguna (misalnya: teacher, student, superadmin).
	NomorIdentitas *string   `json:"nomor_identitas,omitempty"`   // Nomor identitas pengguna (opsional, bisa NULL di DB). "omitempty" berarti tidak disertakan jika nilainya kosong.
	Username       *string   `json:"username"`                    // Username pengguna (opsional, bisa NULL di DB).
	CreatedAt      time.Time `json:"created_at"`                  // Timestamp ketika akun pengguna dibuat.
}

// UserRegisterRequest mendefinisikan struktur data untuk permintaan registrasi pengguna baru.
// Ini adalah data yang diharapkan diterima dari client saat pendaftaran.
type UserRegisterRequest struct {
	NamaLengkap    string `json:"nama_lengkap"`
	Email          string `json:"email"`
	Password       string `json:"password"`
	Peran          string `json:"peran"`
	NomorIdentitas string `json:"nomor_identitas,omitempty"` // Field opsional.
	Username       string `json:"username"`                  // Field opsional.
}

// UserLoginRequest mendefinisikan struktur data untuk permintaan login pengguna.
// Field 'identifier' dapat berupa username atau email pengguna.
type UserLoginRequest struct {
	Identifier string `json:"identifier"` // Username atau email pengguna.
	Password   string `json:"password"`   // Password pengguna.
}

// UserLoginResponse adalah struktur respons untuk permintaan login.
// Catatan: Struktur ini disebut sebagai "deprecated" dalam kode asli,
// yang menunjukkan bahwa sistem mungkin sekarang mengelola otentikasi melalui cookie HttpOnly
// dan mengembalikan objek User secara langsung daripada token di body respons.
type UserLoginResponse struct {
	Token string `json:"token"` // Token JWT yang dihasilkan setelah login berhasil.
}