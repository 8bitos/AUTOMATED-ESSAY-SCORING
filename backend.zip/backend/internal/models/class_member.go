package models

import "time" // Mengimpor package time untuk timestamp.

// ClassMember merepresentasikan keanggotaan seorang siswa dalam sebuah kelas.
// Struktur ini berkorespondensi dengan tabel `class_members` di database.
type ClassMember struct {
	ID         string    `json:"id"`           // ID unik keanggotaan kelas, biasanya UUID.
	ClassID    string    `json:"class_id"`     // ID kelas tempat siswa menjadi anggota (Foreign Key ke tabel classes).
	UserID     string    `json:"user_id"`      // ID siswa yang menjadi anggota (Foreign Key ke tabel users).
	StudentName  string    `json:"student_name"` // Nama siswa. Ini adalah field denormalized untuk kemudahan tampilan di layanan.
	StudentEmail string    `json:"student_email"` // Email siswa. Ini juga field denormalized untuk kemudahan tampilan di layanan.
	JoinedAt   time.Time `json:"joined_at"`    // Timestamp ketika siswa bergabung dengan kelas.
}